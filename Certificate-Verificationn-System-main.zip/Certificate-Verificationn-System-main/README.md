# Certificate-Verificationn-System
The Certificate Verification System is designed to streamline the management and retrieval of certificates for students. Built using the MERN stack (MongoDB, Express.js, React, and Node.js).
